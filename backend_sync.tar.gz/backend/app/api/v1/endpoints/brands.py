"""
Brand CRUD API 엔드포인트

브랜드 생성, 조회, 수정, 삭제 기능

MVP P0-1 Brand OS Module:
- Brand Document 업로드 API
- Brand URL 크롤링 API
- Brand Document 목록 조회 API
"""

from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from uuid import UUID
from datetime import datetime
import logging
from pydantic import BaseModel

from app.core.database import get_db
from app.models.user import User
from app.models.brand import Brand, BrandDocument, DocumentType
from app.schemas.brand import (
    BrandCreate, BrandUpdate, BrandResponse,
    BrandDocumentCreate, BrandDocumentUpdate, BrandDocumentCrawl, BrandDocumentResponse,
    BrandDocumentListResponse
)
from app.schemas.brand_analyzer import BrandAnalysisInputV1, BrandDNAOutputV1, BrandDocumentInput
from app.services.agents.brand_analyzer import get_brand_analyzer_agent
from app.services.agents.data_cleaner import get_data_cleaner_agent
from app.services.agents.base import AgentRequest, AgentError
from app.services.crawlers import get_web_crawler, WebCrawlerError
from app.auth.jwt import get_current_user, get_current_user_optional

router = APIRouter()
logger = logging.getLogger(__name__)

DEMO_BRAND_ID = UUID('00000000-0000-0000-0000-000000000000')

def get_or_create_demo_brand(db: Session) -> Brand:
    """데모 브랜드를 조회하거나 생성합니다."""
    brand = db.query(Brand).filter(Brand.id == DEMO_BRAND_ID).first()
    if brand:
        return brand
        
    # 데모 브랜드 생성 (첫 번째 사용자를 소유자로 지정)
    # 주의: 실제 운영 환경에서는 별도의 데모 계정을 사용해야 함
    owner = db.query(User).first()
    if not owner:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="No users found to create demo brand"
        )
        
    brand = Brand(
        id=DEMO_BRAND_ID,
        owner_id=owner.id,
        name="Demo Brand",
        slug="demo-brand",
        description="A demo brand for anonymous users",
        brand_kit={}
    )
    db.add(brand)
    db.commit()
    db.refresh(brand)
    return brand

@router.post("/", response_model=BrandResponse, status_code=status.HTTP_201_CREATED)
async def create_brand(
    brand_data: BrandCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    새로운 브랜드를 생성합니다.

    Args:
        brand_data: 브랜드 생성 데이터
        current_user: 현재 인증된 사용자
        db: 데이터베이스 세션

    Returns:
        생성된 브랜드 정보
    """
    # slug 중복 확인
    existing_brand = db.query(Brand).filter(Brand.slug == brand_data.slug).first()
    if existing_brand:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Brand with slug '{brand_data.slug}' already exists"
        )

    # 브랜드 생성
    brand = Brand(
        **brand_data.model_dump(),
        owner_id=current_user.id
    )
    db.add(brand)
    db.commit()
    db.refresh(brand)

    return brand


@router.get("/", response_model=List[BrandResponse])
async def list_brands(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    사용자의 브랜드 목록을 조회합니다.

    Args:
        skip: 건너뛸 레코드 수
        limit: 조회할 최대 레코드 수
        current_user: 현재 인증된 사용자
        db: 데이터베이스 세션

    Returns:
        브랜드 목록
    """
    brands = db.query(Brand).filter(
        Brand.owner_id == current_user.id,
        Brand.deleted_at == None
    ).offset(skip).limit(limit).all()

    return brands


@router.get("/{brand_id}", response_model=BrandResponse)
async def get_brand(
    brand_id: UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    특정 브랜드의 상세 정보를 조회합니다.

    Args:
        brand_id: 브랜드 ID
        current_user: 현재 인증된 사용자
        db: 데이터베이스 세션

    Returns:
        브랜드 상세 정보

    Raises:
        HTTPException: 브랜드를 찾을 수 없거나 권한이 없는 경우
    """
    brand = db.query(Brand).filter(
        Brand.id == brand_id,
        Brand.deleted_at == None
    ).first()

    if not brand:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Brand not found"
        )

    # 권한 확인 (소유자만 조회 가능)
    if brand.owner_id != current_user.id and current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )

    return brand


@router.patch("/{brand_id}", response_model=BrandResponse)
async def update_brand(
    brand_id: UUID,
    brand_data: BrandUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    브랜드 정보를 수정합니다.

    Args:
        brand_id: 브랜드 ID
        brand_data: 수정할 데이터
        current_user: 현재 인증된 사용자
        db: 데이터베이스 세션

    Returns:
        수정된 브랜드 정보

    Raises:
        HTTPException: 브랜드를 찾을 수 없거나 권한이 없는 경우
    """
    brand = db.query(Brand).filter(
        Brand.id == brand_id,
        Brand.deleted_at == None
    ).first()

    if not brand:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Brand not found"
        )

    # 권한 확인
    if brand.owner_id != current_user.id and current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )

    # 수정
    update_data = brand_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(brand, key, value)

    db.commit()
    db.refresh(brand)

    return brand


@router.delete("/{brand_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_brand(
    brand_id: UUID,
    hard_delete: bool = False,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    브랜드를 삭제합니다 (기본: Soft Delete).

    Args:
        brand_id: 브랜드 ID
        hard_delete: True면 완전 삭제, False면 소프트 삭제
        current_user: 현재 인증된 사용자
        db: 데이터베이스 세션

    Raises:
        HTTPException: 브랜드를 찾을 수 없거나 권한이 없는 경우
    """
    brand = db.query(Brand).filter(Brand.id == brand_id).first()

    if not brand:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Brand not found"
        )

    # 권한 확인
    if brand.owner_id != current_user.id and current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )

    if hard_delete:
        # 완전 삭제
        db.delete(brand)
    else:
        # 소프트 삭제
        from datetime import datetime
        brand.deleted_at = datetime.utcnow()

    db.commit()


# ==========================================
# Brand Document APIs (MVP P0-1)
# ==========================================

@router.post("/{brand_id}/documents", response_model=BrandDocumentResponse, status_code=status.HTTP_201_CREATED)
async def upload_brand_document(
    brand_id: UUID,
    file: UploadFile = File(...),
    title: str | None = None,
    document_type: str = "pdf",
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    브랜드 문서를 업로드합니다 (PDF, 이미지, 브로슈어 등).
    
    * 인증되지 않은 사용자는 Demo Brand에 대해서만 업로드 가능
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(
            Brand.id == brand_id,
            Brand.deleted_at == None
        ).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # 파일 타입 검증
    allowed_types = {
        "pdf": ["application/pdf"],
        "image": ["image/jpeg", "image/png", "image/gif", "image/webp"],
        "brochure": ["application/pdf", "image/jpeg", "image/png"]
    }

    if document_type not in allowed_types:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid document_type. Must be one of: pdf, image, brochure"
        )

    if file.content_type not in allowed_types.get(document_type, []):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid file type for {document_type}. Allowed: {allowed_types[document_type]}"
        )

    # 파일 저장 (실제 구현에서는 S3 업로드)
    # TODO: S3 업로드 로직 구현
    file_content = await file.read()
    file_size = len(file_content)

    # 임시 파일 경로 (실제로는 S3 URL)
    file_url = f"/tmp/{brand_id}/{file.filename}"

    # BrandDocument 생성
    document = BrandDocument(
        brand_id=brand_id,
        title=title or file.filename,
        document_type=DocumentType(document_type),
        file_url=file_url,
        file_size=file_size,
        mime_type=file.content_type,
        processed="pending",
        document_metadata={
            "original_filename": file.filename,
            "upload_user_id": str(current_user.id) if current_user else "anonymous"
        }
    )

    db.add(document)
    db.commit()
    db.refresh(document)

    logger.info(f"Document uploaded: {document.id} for brand {brand_id}")

    return document


@router.post("/{brand_id}/documents/crawl", response_model=BrandDocumentResponse, status_code=status.HTTP_201_CREATED)
async def crawl_brand_url(
    brand_id: UUID,
    crawl_data: BrandDocumentCrawl,
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    브랜드 URL을 크롤링하여 문서로 저장합니다.
    
    * 인증되지 않은 사용자는 Demo Brand에 대해서만 크롤링 가능
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(
            Brand.id == brand_id,
            Brand.deleted_at == None
        ).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # URL 프로토콜 자동 추가
    url = crawl_data.url.strip()
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
        logger.info(f"Added https:// to URL: {url}")

    # 중복 URL 체크
    existing_doc = db.query(BrandDocument).filter(
        BrandDocument.brand_id == brand_id,
        BrandDocument.source_url == url,
        BrandDocument.processed == "completed"
    ).first()

    if existing_doc:
        logger.info(f"URL already crawled: {url}, returning existing document {existing_doc.id}")
        return existing_doc

    # URL 크롤링 (동기 실행)
    try:
        crawler = get_web_crawler(timeout=30)

        # 다중 페이지 크롤링 또는 단일 페이지 크롤링
        if crawl_data.multi_page:
            logger.info(f"Multi-page crawling enabled: max_pages={crawl_data.max_pages}")
            crawl_result = await crawler.crawl_brand_site(
                url,
                max_pages=crawl_data.max_pages,
                include_categories=crawl_data.include_categories
            )
            raw_text = crawl_result.get("combined_text", "")
            title_from_crawl = crawl_result.get("metadata", {}).get("main_title", f"Brand Site: {url}")
            description = crawl_result.get("metadata", {}).get("main_description")
            categories = crawl_result.get("categories", [])
            page_count = crawl_result.get("page_count", 1)
            crawled_urls = crawl_result.get("metadata", {}).get("crawled_urls", [url])

            extra_metadata = {
                "multi_page": True,
                "page_count": page_count,
                "crawled_urls": crawled_urls,
                "categories": categories,
                "pages": [
                    {"url": p["url"], "type": p["page_type"], "title": p["title"]}
                    for p in crawl_result.get("pages", [])
                ]
            }
        else:
            crawl_result = await crawler.crawl(url)
            raw_text = crawl_result.get("extracted_text", "")
            title_from_crawl = crawl_result.get("title", f"Crawled from {url}")
            description = crawl_result.get("description")
            categories = []
            page_count = 1
            extra_metadata = {"multi_page": False}

        # DataCleanerAgent로 브랜드 분석용 텍스트 정제
        clean_text = raw_text
        extracted_keywords = []
        cleaning_actions = []

        try:
            cleaner = get_data_cleaner_agent()
            clean_result = await cleaner.clean_brand_text(raw_text)
            clean_text = clean_result.get("clean_text", raw_text)
            extracted_keywords = clean_result.get("extracted_keywords", [])
            cleaning_actions = clean_result.get("actions_performed", [])
            logger.info(
                f"Text cleaned for brand analysis: {len(raw_text)} -> {len(clean_text)} chars, "
                f"actions: {cleaning_actions}"
            )
        except Exception as clean_error:
            logger.warning(f"Text cleaning failed, using raw text: {str(clean_error)}")
            # 정제 실패해도 원본 텍스트로 진행

        # 카테고리를 키워드에 추가
        if categories:
            extracted_keywords = list(set(extracted_keywords + categories))

        # BrandDocument 생성
        document = BrandDocument(
            brand_id=brand_id,
            title=crawl_data.title or title_from_crawl,
            document_type=DocumentType.URL,
            source_url=url,
            extracted_text=raw_text,  # 원본 텍스트 저장
            clean_text=clean_text,  # 정제된 텍스트 저장
            extracted_keywords=extracted_keywords if extracted_keywords else None,
            processed="completed",  # 크롤링 완료
            document_metadata={
                "crawl_user_id": str(current_user.id) if current_user else "anonymous",
                "crawl_requested_at": datetime.utcnow().isoformat(),
                "description": description,
                "cleaning_actions": cleaning_actions,
                "raw_text_length": len(raw_text),
                "clean_text_length": len(clean_text),
                **extra_metadata
            }
        )

        db.add(document)

        # Demo Brand인 경우, 크롤링한 페이지 타이틀에서 브랜드 이름 추출하여 업데이트
        # "Demo Brand"라는 이름 대신 실제 브랜드 이름 사용
        if brand_id == DEMO_BRAND_ID and brand.name == "Demo Brand" and title_from_crawl:
            # 타이틀에서 브랜드 이름 추출 (예: "미리캔버스 - 디자인 플랫폼" -> "미리캔버스")
            extracted_brand_name = title_from_crawl.split(' - ')[0].split(' | ')[0].split(' : ')[0].strip()
            # URL에서 도메인 추출하여 website_url 업데이트
            from urllib.parse import urlparse
            parsed_url = urlparse(url)
            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"

            if extracted_brand_name and len(extracted_brand_name) <= 100:
                brand.name = extracted_brand_name
                brand.website_url = base_url
                logger.info(
                    f"Demo Brand name updated: 'Demo Brand' -> '{extracted_brand_name}', "
                    f"website_url: {base_url}"
                )

        db.commit()
        db.refresh(document)

        logger.info(
            f"URL crawled successfully: {document.id} for brand {brand_id}, "
            f"URL: {url}, pages: {page_count}, raw: {len(raw_text)} chars, clean: {len(clean_text)} chars"
        )

        return document

    except WebCrawlerError as e:
        # 크롤링 실패 시 pending 상태로 저장
        logger.error(f"Crawling failed for {url}: {str(e)}")

        document = BrandDocument(
            brand_id=brand_id,
            title=crawl_data.title or f"Crawled from {url}",
            document_type=DocumentType.URL,
            source_url=url,
            processed="failed",
            document_metadata={
                "crawl_user_id": str(current_user.id) if current_user else "anonymous",
                "crawl_requested_at": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

        db.add(document)
        db.commit()
        db.refresh(document)

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Crawling failed: {str(e)}"
        )


@router.get("/{brand_id}/documents", response_model=BrandDocumentListResponse)
async def list_brand_documents(
    brand_id: UUID,
    skip: int = 0,
    limit: int = 100,
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    브랜드의 문서 목록을 조회합니다.
    
    * 인증되지 않은 사용자는 Demo Brand에 대해서만 조회 가능
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(
            Brand.id == brand_id,
            Brand.deleted_at == None
        ).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # 문서 목록 조회
    documents = db.query(BrandDocument).filter(
        BrandDocument.brand_id == brand_id
    ).offset(skip).limit(limit).all()

    total = db.query(BrandDocument).filter(
        BrandDocument.brand_id == brand_id
    ).count()

    return BrandDocumentListResponse(
        documents=documents,
        total=total
    )


@router.patch("/{brand_id}/documents/{document_id}", response_model=BrandDocumentResponse)
async def update_brand_document(
    brand_id: UUID,
    document_id: UUID,
    update_data: BrandDocumentUpdate,
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    브랜드 문서를 수정합니다 (크롤링된 텍스트 편집).

    수정 가능한 필드:
    - title: 문서 제목
    - extracted_text: 원본 크롤링 텍스트
    - clean_text: 정제된 텍스트 (브랜드 분석용)
    - extracted_keywords: 키워드 목록
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(
            Brand.id == brand_id,
            Brand.deleted_at == None
        ).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # 문서 조회
    document = db.query(BrandDocument).filter(
        BrandDocument.id == document_id,
        BrandDocument.brand_id == brand_id
    ).first()

    if not document:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found"
        )

    # 필드 업데이트
    update_dict = update_data.model_dump(exclude_unset=True)
    for key, value in update_dict.items():
        setattr(document, key, value)

    # 메타데이터에 수정 이력 추가
    old_metadata = document.document_metadata or {}
    document.document_metadata = {
        **old_metadata,
        "last_edited_by": str(current_user.id) if current_user else "anonymous",
        "last_edited_at": datetime.utcnow().isoformat(),
        "manually_edited": True
    }

    db.commit()
    db.refresh(document)

    logger.info(f"Document updated: {document_id} for brand {brand_id}, fields: {list(update_dict.keys())}")

    return document


@router.delete("/{brand_id}/documents/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_brand_document(
    brand_id: UUID,
    document_id: UUID,
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    브랜드 문서를 삭제합니다.
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(Brand.id == brand_id).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # 문서 조회
    document = db.query(BrandDocument).filter(
        BrandDocument.id == document_id,
        BrandDocument.brand_id == brand_id
    ).first()

    if not document:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found"
        )

    # 문서 삭제 (CASCADE로 자동 삭제되지만 명시적으로 처리)
    db.delete(document)
    db.commit()

    logger.info(f"Document deleted: {document_id} from brand {brand_id}")


# ==========================================
# BrandAnalyzerAgent API (MVP P0-1)
# ==========================================

class AnalyzeBrandRequest(BaseModel):
    """Brand DNA 분석 요청 (선택된 문서만 분석)"""
    document_ids: list[str] | None = None  # None이면 모든 문서 분석
    llm_provider: str | None = None  # LLM 선택: ollama, openai, anthropic, gemini (None이면 자동 선택)


class RecrawlRequest(BaseModel):
    """URL 재크롤링 요청"""
    document_id: str


@router.post("/{brand_id}/documents/{document_id}/recrawl", response_model=BrandDocumentResponse)
async def recrawl_brand_document(
    brand_id: UUID,
    document_id: UUID,
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    기존 URL 문서를 재크롤링하여 정제 로직을 다시 적용합니다.

    - DataCleanerAgent V2로 정제된 텍스트 업데이트
    - 원본 URL은 유지하고 텍스트만 새로 추출/정제
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(
            Brand.id == brand_id,
            Brand.deleted_at == None
        ).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # 기존 문서 조회
    document = db.query(BrandDocument).filter(
        BrandDocument.id == document_id,
        BrandDocument.brand_id == brand_id
    ).first()

    if not document:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found"
        )

    if document.document_type != DocumentType.URL or not document.source_url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only URL documents can be recrawled"
        )

    url = document.source_url
    logger.info(f"Recrawling document {document_id}: {url}")

    # URL 재크롤링
    try:
        crawler = get_web_crawler(timeout=30)
        crawl_result = await crawler.crawl(url)

        raw_text = crawl_result.get("extracted_text", "")

        # DataCleanerAgent로 브랜드 분석용 텍스트 정제
        clean_text = raw_text
        extracted_keywords = []
        cleaning_actions = []

        try:
            cleaner = get_data_cleaner_agent()
            clean_result = await cleaner.clean_brand_text(raw_text)
            clean_text = clean_result.get("clean_text", raw_text)
            extracted_keywords = clean_result.get("extracted_keywords", [])
            cleaning_actions = clean_result.get("actions_performed", [])
            logger.info(
                f"Text recleaned for brand analysis: {len(raw_text)} -> {len(clean_text)} chars, "
                f"actions: {cleaning_actions}"
            )
        except Exception as clean_error:
            logger.warning(f"Text cleaning failed, using raw text: {str(clean_error)}")

        # 문서 업데이트
        document.extracted_text = raw_text
        document.clean_text = clean_text
        document.extracted_keywords = extracted_keywords if extracted_keywords else None
        document.processed = "completed"
        document.title = crawl_result.get("title", document.title)

        # 메타데이터 업데이트
        old_metadata = document.document_metadata or {}
        document.document_metadata = {
            **old_metadata,
            "recrawl_user_id": str(current_user.id) if current_user else "anonymous",
            "recrawled_at": datetime.utcnow().isoformat(),
            "description": crawl_result.get("description"),
            "cleaning_actions": cleaning_actions,
            "raw_text_length": len(raw_text),
            "clean_text_length": len(clean_text),
            **crawl_result.get("metadata", {})
        }

        db.commit()
        db.refresh(document)

        logger.info(
            f"Document recrawled successfully: {document_id}, "
            f"raw: {len(raw_text)} chars, clean: {len(clean_text)} chars"
        )

        return document

    except WebCrawlerError as e:
        logger.error(f"Recrawling failed for {url}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Recrawling failed: {str(e)}"
        )


@router.get("/{brand_id}/dna")
async def get_brand_dna(
    brand_id: UUID,
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    저장된 Brand DNA 조회 (이력 포함)

    이전에 분석된 Brand DNA가 있으면 반환, 없으면 null 반환

    응답 구조:
    - 새 구조: { current: {...}, history: [...] }
    - 기존 구조 (하위 호환): { current: 기존데이터, history: [기존데이터] }
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(
            Brand.id == brand_id,
            Brand.deleted_at == None
        ).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # Brand DNA가 없으면 null 반환
    if not brand.brand_dna:
        return None

    try:
        dna_data = brand.brand_dna

        # 새 구조 (history 키가 있는 경우) 그대로 반환
        if isinstance(dna_data, dict) and "history" in dna_data:
            return dna_data

        # 기존 구조 (단일 분석 결과) -> 새 구조로 변환
        if isinstance(dna_data, dict):
            import uuid as uuid_module
            if "analysis_id" not in dna_data:
                dna_data["analysis_id"] = str(uuid_module.uuid4())
            return {
                "current": dna_data,
                "history": [dna_data]
            }

        return None
    except Exception as e:
        logger.warning(f"Failed to parse brand_dna for brand {brand_id}: {e}")
        return None


@router.post("/{brand_id}/analyze", response_model=BrandDNAOutputV1)
async def analyze_brand(
    brand_id: UUID,
    request: AnalyzeBrandRequest | None = None,
    current_user: User | None = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    브랜드 분석 및 Brand DNA 자동 생성

    - document_ids가 제공되면 해당 문서만 분석
    - document_ids가 None이면 모든 문서 분석
    """
    # Demo Brand 처리
    if not current_user:
        if brand_id == DEMO_BRAND_ID:
            brand = get_or_create_demo_brand(db)
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required"
            )
    else:
        # 브랜드 존재 및 권한 확인
        brand = db.query(Brand).filter(
            Brand.id == brand_id,
            Brand.deleted_at == None
        ).first()

        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Brand not found"
            )

        if brand.owner_id != current_user.id and current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )

    # 문서 조회 (선택된 문서만 또는 전체)
    query = db.query(BrandDocument).filter(
        BrandDocument.brand_id == brand_id,
        BrandDocument.processed == "completed"  # 완료된 문서만
    )

    # document_ids가 제공되면 해당 문서만 필터링
    if request and request.document_ids:
        query = query.filter(BrandDocument.id.in_(request.document_ids))

    documents = query.all()

    if not documents:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No processed documents found. Please upload and process documents first."
        )

    # BrandDocumentInput 변환
    # clean_text가 있으면 우선 사용 (브랜드 분석에 최적화된 정제된 텍스트)
    # clean_text가 없으면 원본 extracted_text 사용
    document_inputs = []
    for doc in documents:
        # 정제된 텍스트 우선, 없으면 원본 사용
        text_to_analyze = doc.clean_text if doc.clean_text else doc.extracted_text
        if text_to_analyze:  # 텍스트가 있는 문서만
            document_inputs.append(
                BrandDocumentInput(
                    type=doc.document_type.value,
                    extracted_text=text_to_analyze,
                    title=doc.title
                )
            )

    logger.info(
        f"Analyzing {len(document_inputs)} documents for brand {brand_id}, "
        f"using clean_text: {sum(1 for d in documents if d.clean_text)}/{len(documents)}"
    )

    if not document_inputs:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No documents with extracted text found. Please ensure documents are processed."
        )

    # BrandAnalysisInput 생성
    analysis_input = BrandAnalysisInputV1(
        brand_name=brand.name,
        documents=document_inputs,
        website_url=brand.website_url,
        industry=brand.industry,
        existing_brand_kit=brand.brand_kit
    )

    # BrandAnalyzerAgent 실행
    try:
        agent = get_brand_analyzer_agent()
        agent_request = AgentRequest(
            task="brand_dna_generation",
            payload=analysis_input.model_dump(),
            llm_provider=request.llm_provider if request else None
        )

        response = await agent.execute(agent_request)

        # Output 추출
        if not response.outputs or len(response.outputs) == 0:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="BrandAnalyzerAgent returned no output"
            )

        brand_dna_output = BrandDNAOutputV1(**response.outputs[0].value)

        # LLM 정보 추가 (response.meta에서 추출)
        if response.meta:
            brand_dna_output.llm_provider = response.meta.get("llm_provider")
            brand_dna_output.llm_model = response.meta.get("llm_model")

        # 분석 결과에 ID, 타임스탬프 추가
        import uuid as uuid_module
        analysis_result = brand_dna_output.model_dump()
        analysis_result["analysis_id"] = str(uuid_module.uuid4())
        analysis_result["analyzed_at"] = datetime.utcnow().isoformat()

        # Brand DNA 이력을 배열로 저장 (기존 + 새 분석 결과)
        # brand_dna가 dict인 경우 (기존 단일 분석) -> 배열로 변환
        # brand_dna가 dict이고 "history" 키가 있는 경우 -> 기존 이력에 추가
        existing_dna = brand.brand_dna or {}

        if isinstance(existing_dna, dict) and "history" in existing_dna:
            # 이미 이력 구조가 있는 경우
            history = existing_dna.get("history", [])
        elif isinstance(existing_dna, dict) and existing_dna:
            # 기존 단일 분석 결과가 있는 경우 -> 이력으로 변환
            # (기존 데이터에 analysis_id가 없으면 생성)
            if "analysis_id" not in existing_dna:
                existing_dna["analysis_id"] = str(uuid_module.uuid4())
                existing_dna["analyzed_at"] = existing_dna.get("analyzed_at", datetime.utcnow().isoformat())
            history = [existing_dna]
        else:
            # 처음 분석
            history = []

        # 새 분석 결과 추가 (최대 10개 유지)
        history.append(analysis_result)
        if len(history) > 10:
            history = history[-10:]  # 최신 10개만 유지

        # brand_dna 저장 구조: { "current": 현재 선택된 분석, "history": 이력 배열 }
        brand.brand_dna = {
            "current": analysis_result,
            "history": history
        }

        # suggested_brand_kit을 brand_kit에 병합 (기존 값 유지)
        if not brand.brand_kit:
            brand.brand_kit = {}

        suggested_kit = brand_dna_output.suggested_brand_kit.model_dump()

        # 기존 brand_kit이 없는 항목만 suggested_brand_kit으로 채움
        if "colors" not in brand.brand_kit:
            brand.brand_kit["colors"] = {
                "primary": suggested_kit.get("primary_colors", []),
                "secondary": suggested_kit.get("secondary_colors", [])
            }
        if "fonts" not in brand.brand_kit:
            brand.brand_kit["fonts"] = suggested_kit.get("fonts", {})
        if "tone_keywords" not in brand.brand_kit:
            brand.brand_kit["tone_keywords"] = suggested_kit.get("tone_keywords", [])
        if "forbidden_expressions" not in brand.brand_kit:
            brand.brand_kit["forbidden_expressions"] = suggested_kit.get("forbidden_expressions", [])

        db.commit()
        db.refresh(brand)

        logger.info(
            f"Brand DNA generated for brand {brand_id}, "
            f"confidence_score: {brand_dna_output.confidence_score}, "
            f"documents analyzed: {len(document_inputs)}"
        )

        return brand_dna_output

    except AgentError as e:
        logger.error(f"BrandAnalyzerAgent error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Brand analysis failed: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Unexpected error during brand analysis: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Brand analysis failed: {str(e)}"
        )
