from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from typing import Optional, Literal
from enum import Enum
import os
from urllib.parse import quote_plus


class WhisperMode(str, Enum):
    """Whisper STT 전략 모드"""
    openai = "openai"  # OpenAI Whisper API 전용
    local = "local"  # 로컬 서버 전용
    hybrid_cost = "hybrid_cost"  # 비용/속도 균형
    hybrid_quality = "hybrid_quality"  # 품질 우선


class WhisperLocalBackend(str, Enum):
    """로컬 Whisper 백엔드 타입"""
    faster_whisper = "faster_whisper"  # faster-whisper (GPU, CTranslate2)
    whisper_cpp = "whisper_cpp"  # whisper.cpp (CPU, C++)
    none = "none"  # 로컬 백엔드 사용 안 함

class Settings(BaseSettings):
    # Application
    APP_NAME: str = "Sparklio AI Marketing Studio"
    APP_VERSION: str = "0.1.0"
    APP_ENV: str = "development"
    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8000
    API_SECRET_KEY: str = "your-secret-key-change-in-production"

    # PostgreSQL
    POSTGRES_HOST: str = "100.123.51.5"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "sparklio"
    POSTGRES_USER: str = "sparklio"
    POSTGRES_PASSWORD: str = "sparklio_secure_2025"

    # Redis
    REDIS_HOST: str = "100.123.51.5"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: str = ""

    # MinIO
    MINIO_ENDPOINT: str = "100.123.51.5:9000"
    MINIO_PUBLIC_URL: str = "http://100.123.51.5:9000"  # Public URL for external access
    MINIO_ACCESS_KEY: str = "sparklio"
    MINIO_SECRET_KEY: str = "sparklio_minio_2025"
    MINIO_SECURE: bool = False
    MINIO_BUCKET_PREFIX: str = "dev-"

    # Generator Mode (mock | live) - 소문자 필드명 사용
    generator_mode: Literal["mock", "live"] = Field(
        "live", # Default to live
        env="GENERATOR_MODE"
    )

    # AI Workers - LLM (Ollama) - 소문자 필드명 사용
    ollama_base_url: str = Field(
        "http://100.120.180.42:11434",
        env="OLLAMA_BASE_URL"
    )
    ollama_timeout: int = Field(120, env="OLLAMA_TIMEOUT")
    ollama_default_model: str = Field("llama3.2:latest", env="OLLAMA_DEFAULT_MODEL")

    # OpenAI API
    openai_api_key: str = Field("", env="OPENAI_API_KEY")
    openai_default_model: str = Field("gpt-4o-mini", env="OPENAI_DEFAULT_MODEL")
    openai_timeout: int = Field(60, env="OPENAI_TIMEOUT")

    # Anthropic API (Claude)
    anthropic_api_key: str = Field("", env="ANTHROPIC_API_KEY")
    anthropic_default_model: str = Field(
        "claude-3-5-haiku-20241022",
        env="ANTHROPIC_DEFAULT_MODEL"
    )
    anthropic_timeout: int = Field(60, env="ANTHROPIC_TIMEOUT")

    # Google Gemini API
    google_api_key: str = Field("", env="GOOGLE_API_KEY")
    gemini_text_model: str = Field(
        "gemini-2.5-flash",
        env="GEMINI_TEXT_MODEL"
    )
    gemini_image_model: str = Field(
        "gemini-2.0-flash-exp",
        env="GEMINI_IMAGE_MODEL"
    )
    gemini_timeout: int = Field(60, env="GEMINI_TIMEOUT")

    # Unsplash API (C팀 Photos Tab 지원)
    unsplash_access_key: str = Field("", env="UNSPLASH_ACCESS_KEY")



    # AI Workers - Media (ComfyUI) - 소문자 필드명 사용
    comfyui_base_url: str = Field(
        "http://100.120.180.42:8188",
        env="COMFYUI_BASE_URL"
    )
    comfyui_timeout: int = Field(300, env="COMFYUI_TIMEOUT")

    # Legacy endpoints (deprecated, use ollama_base_url instead)
    OLLAMA_ENDPOINT: str = "http://100.120.180.42:11434"
    COMFYUI_ENDPOINT: str = "http://100.120.180.42:8188"

    # File Upload
    MAX_FILE_SIZE_MB: int = 100
    ALLOWED_FILE_TYPES: str = "image/jpeg,image/png,image/webp,video/mp4,text/plain"

    # Presigned URL
    PRESIGNED_URL_EXPIRY: int = 3600  # 1 hour

    # Vector Search
    EMBEDDING_DIMENSION: int = 1536

    # Video Pipeline
    video_mock_images: bool = Field(False, env="VIDEO_MOCK_IMAGES")

    # Video Render Mode Control (4단계 확인 플로우 지원)
    video_allow_real: bool = Field(False, env="VIDEO_ALLOW_REAL")  # 실제 AI 영상 생성 허용
    video_default_mode: str = Field("mock", env="VIDEO_DEFAULT_MODE")  # 기본 렌더 모드 (mock|real)
    render_daily_cost_limit: float = Field(100.0, env="RENDER_DAILY_COST_LIMIT")  # 일일 비용 한도 ($)

    # AI Video Generation (Image-to-Video)
    luma_api_key: str = Field("", env="LUMA_API_KEY")
    runway_api_key: str = Field("", env="RUNWAY_API_KEY")

    # Whisper STT (Meeting AI)
    whisper_mode: str = Field("hybrid_cost", env="WHISPER_MODE")  # openai | local | hybrid_cost | hybrid_quality
    whisper_local_backend: str = Field("faster_whisper", env="WHISPER_LOCAL_BACKEND")  # whisper_cpp | faster_whisper | none
    whisper_fast_endpoint: str = Field("http://100.123.51.6:9000/transcribe", env="WHISPER_FAST_ENDPOINT")
    whisper_cpp_endpoint: str = Field("http://127.0.0.1:8765/transcribe", env="WHISPER_CPP_ENDPOINT")
    whisper_openai_model: str = Field("whisper-1", env="WHISPER_OPENAI_MODEL")  # OpenAI Whisper model
    whisper_openai_max_minutes: int = Field(20, env="WHISPER_OPENAI_MAX_MINUTES")
    whisper_profile_fast: str = Field("small", env="WHISPER_PROFILE_FAST")
    whisper_profile_balanced: str = Field("medium", env="WHISPER_PROFILE_BALANCED")
    whisper_profile_accurate: str = Field("large-v3", env="WHISPER_PROFILE_ACCURATE")
    whisper_timeout_seconds: int = Field(600, env="WHISPER_TIMEOUT_SECONDS")
    whisper_max_retries: int = Field(2, env="WHISPER_MAX_RETRIES")

    # Database URL (computed)
    @property
    def DATABASE_URL(self) -> str:
        # URL-encode password to handle special characters like @, !, etc.
        password = quote_plus(self.POSTGRES_PASSWORD)
        return f"postgresql://{self.POSTGRES_USER}:{password}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"

    # Redis URL (computed)
    @property
    def REDIS_URL(self) -> str:
        if self.REDIS_PASSWORD:
            return f"redis://:{self.REDIS_PASSWORD}@{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"

    # 하위 호환성을 위한 대문자 속성 (deprecated)
    @property
    def GENERATOR_MODE(self) -> str:
        """Deprecated: Use generator_mode instead"""
        return self.generator_mode

    @property
    def OLLAMA_BASE_URL(self) -> str:
        """Deprecated: Use ollama_base_url instead"""
        return self.ollama_base_url

    @property
    def OLLAMA_TIMEOUT(self) -> int:
        """Deprecated: Use ollama_timeout instead"""
        return self.ollama_timeout

    @property
    def OLLAMA_DEFAULT_MODEL(self) -> str:
        """Deprecated: Use ollama_default_model instead"""
        return self.ollama_default_model

    # OpenAI 대문자 속성
    @property
    def OPENAI_API_KEY(self) -> str:
        return self.openai_api_key

    @property
    def OPENAI_DEFAULT_MODEL(self) -> str:
        return self.openai_default_model

    @property
    def OPENAI_TIMEOUT(self) -> int:
        return self.openai_timeout

    # Anthropic 대문자 속성
    @property
    def ANTHROPIC_API_KEY(self) -> str:
        return self.anthropic_api_key

    @property
    def ANTHROPIC_DEFAULT_MODEL(self) -> str:
        return self.anthropic_default_model

    @property
    def ANTHROPIC_TIMEOUT(self) -> int:
        return self.anthropic_timeout

    # Google 대문자 속성
    @property
    def GOOGLE_API_KEY(self) -> str:
        return self.google_api_key

    @property
    def GEMINI_TEXT_MODEL(self) -> str:
        return self.gemini_text_model

    @property
    def GEMINI_IMAGE_MODEL(self) -> str:
        return self.gemini_image_model

    @property
    def GEMINI_TIMEOUT(self) -> int:
        return self.gemini_timeout

    # Unsplash 대문자 속성
    @property
    def UNSPLASH_ACCESS_KEY(self) -> str:
        return self.unsplash_access_key

    # AI Video 대문자 속성
    @property
    def LUMA_API_KEY(self) -> str:
        return self.luma_api_key

    @property
    def RUNWAY_API_KEY(self) -> str:
        return self.runway_api_key

    # Video Render 대문자 속성
    @property
    def VIDEO_ALLOW_REAL(self) -> bool:
        return self.video_allow_real

    @property
    def VIDEO_DEFAULT_MODE(self) -> str:
        return self.video_default_mode

    @property
    def RENDER_DAILY_COST_LIMIT(self) -> float:
        return self.render_daily_cost_limit

    @property
    def COMFYUI_BASE_URL(self) -> str:
        """Deprecated: Use comfyui_base_url instead"""
        return self.comfyui_base_url

    @property
    def COMFYUI_TIMEOUT(self) -> int:
        """Deprecated: Use comfyui_timeout instead"""
        return self.comfyui_timeout

    # Whisper 대문자 속성
    @property
    def WHISPER_MODE(self) -> str:
        return self.whisper_mode

    @property
    def WHISPER_LOCAL_BACKEND(self) -> str:
        return self.whisper_local_backend

    @property
    def WHISPER_FAST_ENDPOINT(self) -> str:
        return self.whisper_fast_endpoint

    @property
    def WHISPER_CPP_ENDPOINT(self) -> str:
        return self.whisper_cpp_endpoint

    @property
    def WHISPER_OPENAI_MODEL(self) -> str:
        return self.whisper_openai_model

    @property
    def WHISPER_OPENAI_MAX_MINUTES(self) -> int:
        return self.whisper_openai_max_minutes

    @property
    def WHISPER_PROFILE_FAST(self) -> str:
        return self.whisper_profile_fast

    @property
    def WHISPER_PROFILE_BALANCED(self) -> str:
        return self.whisper_profile_balanced

    @property
    def WHISPER_PROFILE_ACCURATE(self) -> str:
        return self.whisper_profile_accurate

    @property
    def WHISPER_TIMEOUT_SECONDS(self) -> int:
        return self.whisper_timeout_seconds

    @property
    def WHISPER_MAX_RETRIES(self) -> int:
        return self.whisper_max_retries

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )

# Global settings instance
settings = Settings()
