# B팀 익일 작업 계획서

**작업일**: 2025-11-18 (월)
**작성자**: B팀 (Backend Team)
**목표**: 통합 테스트 완료 및 배포 준비

---

## 📋 오늘(2025-11-15) 완료 사항 요약

✅ **Phase 4: Admin API & Monitoring 완료**
- Admin API 5개 엔드포인트 구현
- Prometheus 메트릭 6종 추가
- 실제 서버 구동 및 동작 검증
- Git 커밋 완료 (086e579)

✅ **P0 Phase 1-4 전체 완료**
- API 22개 엔드포인트
- Generator 3종, Agent 7종
- DB Models 3개, Redis 캐싱, Prometheus 모니터링

---

## 🎯 익일(2025-11-18) 작업 목표

### 우선순위 1: 통합 테스트 완료 (필수)

**작업 항목**:

#### 1-1. 테스트 데이터 로드
- [ ] PostgreSQL에 테스트 픽스처 로드
  ```bash
  psql -h localhost -U sparklio -d sparklio_db -f tests/fixtures/test_data.sql
  ```
- [ ] 테스트 사용자 생성 확인
  - Admin: `qa@sparklio.ai` / `testpassword`
  - Editor: `qa2@sparklio.ai` / `testpassword`
  - Viewer: `qa-viewer@sparklio.ai` / `testpassword`
- [ ] 테스트 브랜드 3개 생성 확인
- [ ] 테스트 템플릿 3개 생성 확인

**예상 시간**: 30분
**담당**: Backend 개발자
**산출물**: 테스트 데이터 로드 완료 보고

---

#### 1-2. Backend API 통합 테스트 실행
- [ ] Playwright 테스트 실행
  ```bash
  npm run test:backend
  ```
- [ ] 31개 테스트 케이스 통과 확인
  - Generator API 테스트 (3개)
  - Documents API 테스트 (5개)
  - Editor API 테스트 (2개)
  - Templates API 테스트 (7개)
  - Admin API 테스트 (5개)
  - Monitoring 테스트 (2개)
  - 성능 테스트 (7개)
- [ ] 실패 케이스 디버깅 및 수정

**예상 시간**: 2시간
**담당**: Backend 개발자 + QA팀 협업
**산출물**: 테스트 리포트 (통과율, 실패 케이스)

---

#### 1-3. JWT 인증 테스트
- [ ] 로그인 API 테스트
  ```bash
  curl -X POST http://localhost:8000/api/v1/users/login \
    -d '{"email":"qa@sparklio.ai","password":"testpassword"}'
  ```
- [ ] JWT 토큰 발급 확인
- [ ] Admin API 인증 테스트
  ```bash
  TOKEN=$(curl ... | jq -r '.access_token')
  curl -H "Authorization: Bearer $TOKEN" \
    http://localhost:8000/api/v1/admin/users
  ```
- [ ] 7개 Agent 상태 확인
  ```bash
  curl -H "Authorization: Bearer $TOKEN" \
    http://localhost:8000/api/v1/admin/agents
  ```

**예상 시간**: 1시간
**담당**: Backend 개발자
**산출물**: JWT 인증 테스트 결과

---

### 우선순위 2: 성능 최적화 (권장)

**작업 항목**:

#### 2-1. Generator 성능 검증
- [ ] Brand Kit Generator 실행 시간 측정
  - 목표: < 10초
- [ ] Product Detail Generator 실행 시간 측정
  - 목표: < 10초
- [ ] SNS Generator 실행 시간 측정
  - 목표: < 10초
- [ ] 병목 구간 분석 (Agent 실행 시간 로그)

**예상 시간**: 1.5시간
**담당**: Backend 개발자
**산출물**: 성능 테스트 리포트

---

#### 2-2. Redis 캐싱 효율 검증
- [ ] Template 캐싱 HIT 비율 측정
  - 목표: > 80%
- [ ] Brand Learning 캐싱 HIT 비율 측정
  - 목표: > 70%
- [ ] 캐시 TTL 최적화
  - Template: 1시간 (현재)
  - Brand Learning: 6시간 (현재)

**예상 시간**: 1시간
**담당**: Backend 개발자
**산출물**: 캐싱 효율 리포트

---

#### 2-3. Prometheus 메트릭 검증
- [ ] Generator 메트릭 수집 확인
  ```bash
  curl http://localhost:8000/metrics | grep sparklio_generator
  ```
- [ ] Cache 메트릭 수집 확인
  ```bash
  curl http://localhost:8000/metrics | grep sparklio_cache
  ```
- [ ] Document/Template 메트릭 수집 확인
- [ ] Grafana 대시보드 구성 (선택)

**예상 시간**: 1시간
**담당**: Backend 개발자
**산출물**: 메트릭 수집 현황 리포트

---

### 우선순위 3: C팀 Frontend 통합 지원 (필수)

**작업 항목**:

#### 3-1. API 연동 가이드 작성
- [ ] API 엔드포인트 목록 정리
- [ ] 요청/응답 예시 작성
- [ ] 에러 코드 정리
- [ ] CORS 설정 확인

**예상 시간**: 1시간
**담당**: Backend 개발자
**산출물**: `API_INTEGRATION_GUIDE.md`

---

#### 3-2. C팀 연동 테스트 지원
- [ ] Frontend에서 `/api/v1/generate` 호출 테스트
- [ ] Documents API 저장/로드 테스트
- [ ] Editor Action API 테스트
- [ ] CORS 이슈 해결 지원

**예상 시간**: 2시간
**담당**: Backend 개발자 + C팀 협업
**산출물**: 연동 테스트 결과

---

### 우선순위 4: 배포 준비 (선택)

**작업 항목**:

#### 4-1. 환경 변수 설정
- [ ] `.env.production` 작성
- [ ] DB 연결 정보 확인
- [ ] Redis 연결 정보 확인
- [ ] Secret Key 설정

**예상 시간**: 30분
**담당**: Backend 개발자
**산출물**: `.env.production`

---

#### 4-2. Docker 컨테이너 구성 (선택)
- [ ] `Dockerfile` 작성
- [ ] `docker-compose.yml` 작성
- [ ] 로컬 Docker 테스트
- [ ] 이미지 빌드 및 실행 확인

**예상 시간**: 2시간
**담당**: Backend 개발자
**산출물**: Docker 이미지

---

## 📊 작업 시간 예상

| 우선순위 | 작업 | 예상 시간 | 필수 여부 |
|---------|------|-----------|-----------|
| **1** | 통합 테스트 완료 | 3.5시간 | ✅ 필수 |
| **2** | 성능 최적화 | 3.5시간 | ⚠️ 권장 |
| **3** | C팀 통합 지원 | 3시간 | ✅ 필수 |
| **4** | 배포 준비 | 2.5시간 | ⬜ 선택 |
| **합계** | | 12.5시간 | (필수: 6.5시간) |

**권장 작업 순서**:
1. 오전 (4시간): 우선순위 1 (통합 테스트 완료)
2. 오후 전반 (3시간): 우선순위 3 (C팀 통합 지원)
3. 오후 후반 (3.5시간): 우선순위 2 (성능 최적화)

---

## 🚨 예상 이슈 및 대응 방안

### 이슈 1: 테스트 데이터 로드 실패
**증상**: PostgreSQL 연결 오류 또는 테이블 미생성
**대응**:
1. Alembic migration 재실행: `alembic upgrade head`
2. DB 연결 정보 확인: `.env` 파일 검증
3. 수동으로 테스트 사용자 생성

---

### 이슈 2: Playwright 테스트 실패
**증상**: 31개 테스트 중 일부 실패
**대응**:
1. 서버 로그 확인: 에러 메시지 분석
2. 테스트 타임아웃 증가: `playwright.config.ts` 수정
3. Generator 성능 문제 시: Mock Provider로 전환 고려

---

### 이슈 3: C팀 CORS 에러
**증상**: Frontend에서 API 호출 시 CORS 에러
**대응**:
1. `app/main.py` CORS 설정 확인
2. Allowed Origins 추가: `http://localhost:3000`
3. Credentials 허용 확인

---

## 📋 체크리스트

### 작업 시작 전
- [ ] Backend 서버 실행 확인
- [ ] PostgreSQL 연결 확인
- [ ] Redis 연결 확인
- [ ] `.env` 파일 설정 확인

### 작업 중
- [ ] 테스트 데이터 로드 완료
- [ ] 31개 테스트 케이스 통과
- [ ] Admin API 인증 테스트 완료
- [ ] C팀 API 연동 가이드 작성

### 작업 완료 후
- [ ] 일일 작업 보고서 작성
- [ ] Git 커밋 및 푸시
- [ ] 익일 작업 계획서 업데이트
- [ ] A팀, C팀에 진행 상황 공유

---

## 🔗 참고 문서

1. `PHASE4_ADMIN_MONITORING_REPORT.md` - Admin API 사양
2. `PHASE3_TEMPLATE_RAG_REPORT.md` - Redis 캐싱 사양
3. `PHASE2_AGENT_INTEGRATION_REPORT.md` - Editor API 사양
4. `tests/integration/backend-api.spec.ts` - 통합 테스트 코드
5. `tests/fixtures/test_data.sql` - 테스트 픽스처
6. `docs/B_TEAM_WORK_ORDER.md` - B팀 작업 지시서 v2.0

---

## 📞 팀 간 협업 요청 사항

### A팀 (QA)에게
- [ ] Playwright 테스트 실행 방법 공유 요청
- [ ] 테스트 실패 시 로그 공유 요청
- [ ] 성능 테스트 기준 확인 요청

### C팀 (Frontend)에게
- [ ] API 연동 시작 시점 확인 요청
- [ ] CORS 테스트 협조 요청
- [ ] 에러 핸들링 방식 협의 요청

---

## 💡 추가 개선 사항 (향후 작업)

- [ ] Grafana 대시보드 구성
- [ ] Alert 규칙 설정 (실패율 > 10%, 응답 시간 > 10초)
- [ ] Template 추천 알고리즘 구현
- [ ] Feedback 학습 모델 구현
- [ ] RAG Vector DB 연동 (Qdrant/Chroma)
- [ ] Admin Users: 사용자 비활성화/활성화 API
- [ ] Admin Jobs: Job 재실행 API
- [ ] Admin Logs: 로그 조회 및 필터링 API

---

**작성자**: B팀 (Backend)
**작성일**: 2025-11-15
**목표일**: 2025-11-18 (월)

**🚀 내일도 화이팅! 통합 테스트 완료를 목표로!** 💪
