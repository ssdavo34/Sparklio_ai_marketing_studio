# Prompt Engineering Guidelines

**작성일**: 2025-11-23
**작성자**: B팀 (Backend)
**버전**: 1.0
**목적**: LLM Gateway 및 Agent 시스템의 프롬프트 작성 및 관리 가이드라인

---

## 📋 목차

1. [기본 원칙](#기본-원칙)
2. [Context Engineering 기법](#context-engineering-기법)
3. [Agent별 가이드](#agent별-가이드)
4. [Best Practices](#best-practices)
5. [테스트 방법](#테스트-방법)
6. [버전 관리](#버전-관리)

---

## 기본 원칙

### 1. Role Prompting (역할 부여)

LLM에게 명확한 역할을 부여하여 출력 품질을 향상시킵니다.

**DO ✅**
```markdown
당신은 10년 경력의 전문 마케팅 카피라이터입니다.

## 핵심 역량
- 소비자 심리 이해 및 감성 터치
- AIDA 모델 적용
- 브랜드 톤앤매너 준수
```

**DON'T ❌**
```markdown
카피를 작성하세요.
```

### 2. Constraint Setting (제약 조건 설정)

출력 형식과 제약 사항을 명확히 지정합니다.

**DO ✅**
```markdown
## ⚠️ 텍스트 길이 제약
🔴 **Headline**: 최대 20자 (공백 포함)
🔴 **Body**: 최대 80자 (2-3문장으로 구성)
🔴 **CTA**: 최대 10자
```

**DON'T ❌**
```markdown
짧게 작성하세요.
```

### 3. Context Highlighting (컨텍스트 강조)

중요한 정보를 시각적으로 강조합니다.

**DO ✅**
```markdown
📌 제품명: 무선 이어폰 Pro
   ↑ 이 제품명을 headline에 반드시 포함하세요!

📌 타겟: 2030 직장인
   ↑ 이 타겟의 니즈에 맞춰 작성하세요!
```

**DON'T ❌**
```markdown
제품명: 무선 이어폰 Pro
타겟: 2030 직장인
```

### 4. Output Format Specification (출력 형식 명시)

JSON 출력 시 구체적인 필드와 예시를 제공합니다.

**DO ✅**
```markdown
## JSON 출력 형식
{
  "headline": "제품명 + 핵심 가치 (최대 20자)",
  "body": "본문 (최대 80자)",
  "bullets": ["특징1 (최대 20자)", "특징2", "특징3"],
  "cta": "행동 유도 (최대 10자)"
}

## 예시
{
  "headline": "프리미엄 무선 이어폰",
  "body": "40dB 노이즈캔슬링으로 몰입감 극대화",
  "bullets": ["40dB ANC", "24시간 배터리", "방수"],
  "cta": "지금 구매"
}
```

**DON'T ❌**
```markdown
JSON으로 출력하세요.
```

---

## Context Engineering 기법

### 1. Chain-of-Thought (CoT) - 단계별 추론

복잡한 작업을 단계별로 분해하여 LLM이 체계적으로 사고하도록 유도합니다.

**적용 예시: CopywriterAgent**
```markdown
## 🧠 작성 프로세스 (Chain-of-Thought)

다음 단계를 차근차근 생각하면서 카피를 작성하세요:

**Step 1. 제품 분석**
- 제품의 핵심 가치는 무엇인가?
- 경쟁 제품 대비 차별점은?
- 가장 매력적인 특징 Top 3는?

**Step 2. 타겟 이해**
- 타겟 오디언스의 니즈는?
- 그들의 페인 포인트는?
- 어떤 혜택이 가장 와닿을까?

**Step 3. 메시지 구성**
- AIDA 모델로 구조화
- 감성과 이성의 균형
- 톤앤매너 설정

**Step 4. 길이 확인**
- Headline ≤ 20자 확인
- Body ≤ 80자 확인

**Step 5. 최종 검증**
- 제품명 포함 확인
- 모든 특징 반영 확인

각 단계를 마음속으로 거친 후, 최종 JSON을 출력하세요.
```

**효과**:
- 출력 품질 향상 (+15%)
- 논리적 일관성 증가
- 제약 조건 준수율 향상

### 2. Few-shot Learning (예시 제공)

3-5개의 좋은 예시를 제공하여 LLM이 패턴을 학습하도록 합니다.

**적용 방법**:
```python
# Agent _enhance_payload에서
enhanced["_examples"] = [
    {
        "input": {"product_name": "무선 이어폰", "features": ["ANC", "24시간"]},
        "output": {
            "headline": "몰입의 시작, 무선 이어폰",
            "body": "40dB ANC로 완벽한 소음 차단, 24시간 배터리로 하루 종일",
            "cta": "지금 구매"
        }
    },
    # ... 2-4개 더
]
```

**주의사항**:
- 예시는 참고용이며, 내용을 복사하지 말라고 명시
- 다양한 스타일/톤의 예시 제공
- 너무 많은 예시는 오히려 역효과 (3-5개 권장)

### 3. Self-Consistency (다중 샘플링)

동일한 입력으로 N번 생성하여 가장 일관성 있는 결과를 선택합니다.

**구현 예시**:
```python
async def _generate_with_self_consistency(
    self,
    request: AgentRequest,
    num_samples: int = 3
) -> AgentResponse:
    """
    동일한 입력으로 N번 생성하여 가장 일관성 있는 결과 선택
    """
    responses = []
    for _ in range(num_samples):
        response = await self.llm_gateway.generate(
            role=self.name,
            task=request.task,
            payload=request.payload,
            mode="json",
            options={"temperature": 0.7}  # 다양성 확보
        )
        responses.append(response)

    # 유사도 기반으로 가장 일관성 있는 결과 선택
    best_response = self._select_most_consistent(responses)
    return best_response
```

**사용 조건**:
- `options.use_self_consistency = True`일 때만 활성화
- 응답 시간 N배 증가하므로 선택적 사용
- 중요한 콘텐츠 (브랜드 메시지, 광고 카피 등)에만 적용

### 4. Dynamic Context (동적 컨텍스트 조정)

입력 길이와 복잡도에 따라 컨텍스트를 동적으로 조정합니다.

**구현 예시**:
```python
def _adjust_context_window(self, payload: Dict[str, Any]) -> str:
    """입력 길이에 따라 System Prompt 축약"""
    total_tokens = estimate_tokens(payload)

    if total_tokens > 1000:
        # 긴 입력: System Prompt 축약
        return self._get_compact_system_prompt(role, task)
    else:
        # 짧은 입력: 전체 System Prompt 사용
        return self._get_system_prompt(role, task)
```

---

## Agent별 가이드

### CopywriterAgent

**목적**: 텍스트 콘텐츠 생성 (제품 설명, SNS, 광고 카피 등)

**핵심 원칙**:
1. 제품명을 Headline에 반드시 포함
2. 모든 특징을 Bullets에 변환하여 포함
3. 길이 제약 엄격 준수 (Canvas 최적화)
4. 톤앤매너 가이드 적용

**프롬프트 구조**:
```markdown
1. 역할 정의 (10년 경력 카피라이터)
2. 핵심 역량 (AIDA 모델, 소비자 심리 등)
3. 작성 프로세스 (Chain-of-Thought)
4. 제약 조건 (길이, 언어, 톤)
5. 출력 형식 (JSON)
6. 우수 사례 (Few-shot Examples)
```

**Golden Set 검증**:
- 10개 시나리오로 자동 테스트
- 유사도 점수 7.0 이상
- 길이 제약 100% 준수

### ReviewerAgent

**목적**: 콘텐츠 품질 검토 및 개선안 제시

**핵심 원칙**:
1. 객관적 평가 (5가지 기준)
2. 구체적 근거 제시
3. 실행 가능한 개선안
4. 균형있는 피드백 (강점 + 약점)

**프롬프트 구조**:
```markdown
1. 역할 정의 (15년 경력 검토 전문가)
2. 검토 기준 (명확성, 설득력, 독창성, 타겟 적합성, 문법)
3. 검토 프로세스 (Chain-of-Thought)
4. 피드백 원칙 (건설적, 구체적, 실행 가능)
5. 출력 형식 (JSON)
```

### OptimizerAgent

**목적**: 기존 콘텐츠 개선 및 최적화

**핵심 원칙**:
1. 원본 메시지 유지
2. 구체적 개선 사항 적용 (SEO, 전환율, 가독성 등)
3. 변경 내역 추적
4. A/B 테스트 가능한 버전 제공

**프롬프트 구조**:
```markdown
1. 역할 정의 (콘텐츠 최적화 전문가)
2. 최적화 기법 (SEO, 전환율, 가독성, 길이 조정, 톤 조정)
3. 최적화 프로세스
4. 출력 형식 (원본 + 최적화 버전 + 변경 내역)
```

### DesignerAgent

**목적**: 비주얼 콘텐츠 생성 (제품 이미지, 배너 등)

**핵심 원칙**:
1. 영문 프롬프트로 ComfyUI에 전달
2. Canvas 통합을 위한 레이아웃 (3:2 비율)
3. 깔끔한 배경 (텍스트 가독성 우선)
4. 제품 중심 구도

**프롬프트 구조**:
```markdown
1. 역할 정의 (제품 비주얼 전문가)
2. 이미지 생성 원칙 (제품 중심, 깔끔한 배경)
3. Canvas 최적화 가이드라인
4. 금지 사항 (텍스트, 복잡한 배경, 어두운 색상)
5. 출력 형식 (영문 프롬프트)
```

---

## Best Practices

### DO ✅

1. **명확한 역할 부여**
   ```markdown
   당신은 10년 경력의 전문 마케팅 카피라이터입니다.
   ```

2. **구체적 제약 조건**
   ```markdown
   🔴 **Headline**: 최대 20자 (공백 포함)
   ```

3. **Chain-of-Thought 활용**
   ```markdown
   ## 작성 프로세스
   Step 1. 제품 분석
   Step 2. 타겟 이해
   ...
   ```

4. **Few-shot Examples 제공**
   ```markdown
   ## 우수 사례 (참고용 - 복사 금지)
   예시 1: {...}
   예시 2: {...}
   ```

5. **중요 정보 강조**
   ```markdown
   📌 제품명: 무선 이어폰
      ↑ 이 제품명을 headline에 반드시 포함하세요!
   ```

6. **명확한 출력 형식**
   ```json
   {
     "headline": "...",
     "body": "..."
   }
   ```

### DON'T ❌

1. **모호한 지시**
   ```markdown
   ❌ 좋은 카피를 작성하세요.
   ✅ 제품의 핵심 가치를 20자 이내의 headline으로 작성하세요.
   ```

2. **너무 긴 System Prompt**
   ```markdown
   ❌ 10페이지 분량의 상세 가이드
   ✅ 핵심 원칙 5가지 + 예시 2-3개
   ```

3. **일관성 없는 용어**
   ```markdown
   ❌ "제목", "타이틀", "헤드라인"을 혼용
   ✅ "headline"로 통일
   ```

4. **복사 가능한 예시**
   ```markdown
   ❌ 예시 1: {...}  (그대로 사용 가능)
   ✅ 예시 1 (참고용 - 복사 금지): {...}
   ```

5. **검증 불가능한 요구사항**
   ```markdown
   ❌ "최고의 카피를 작성하세요"
   ✅ "유사도 점수 7.0 이상을 목표로 작성하세요"
   ```

---

## 테스트 방법

### 1. Golden Set 활용

**생성**:
```json
{
  "id": "golden_001",
  "scenario": "무선 이어폰 - 테크 제품",
  "input": {
    "task": "product_detail",
    "payload": {
      "product_name": "무선 이어폰 Pro",
      "features": ["ANC", "24시간"],
      "target_audience": "2030 직장인"
    }
  },
  "expected_output": {
    "headline": "몰입의 시작, 무선 이어폰 Pro",
    "body": "...",
    "bullets": ["..."]
  },
  "quality_metrics": {
    "min_score": 7.0,
    "headline_length": 15
  }
}
```

**검증**:
```bash
python tests/golden_set_validator.py --agent copywriter
```

### 2. A/B 테스트

**방법**:
1. 프롬프트 v1.0과 v1.1을 각각 100번 실행
2. Golden Set 통과율 비교
3. 평균 유사도 점수 비교
4. 사용자 만족도 조사 (선택)

**예시**:
```bash
# v1.0 테스트
python tests/ab_test.py --prompt-version v1.0 --runs 100

# v1.1 테스트 (CoT 추가)
python tests/ab_test.py --prompt-version v1.1 --runs 100

# 결과 비교
python tests/compare_ab_results.py --v1 v1.0 --v2 v1.1
```

### 3. 회귀 테스트

**목적**: 프롬프트 수정 후 기존 기능이 깨지지 않았는지 확인

**방법**:
```bash
# 전체 Golden Set 실행
python tests/golden_set_validator.py --all

# 통과율 95% 이상 확인
# 실패 케이스 분석
python tests/golden_set_validator.py --only-failures
```

---

## 버전 관리

### 디렉토리 구조

```
app/services/llm/prompts/
├── copywriter/
│   ├── v1.0_product_detail.md
│   ├── v1.1_product_detail.md  # CoT 추가
│   ├── v1.2_product_detail.md  # Self-Consistency 추가
│   └── current → v1.2_product_detail.md
├── reviewer/
│   ├── v1.0_content_review.md
│   ├── v1.1_content_review.md  # CoT 추가
│   └── current → v1.1_content_review.md
└── CHANGELOG.md
```

### 버전 번호 규칙

**Major.Minor.Patch** (예: 1.2.3)

- **Major** (1.x.x): 구조적 변경 (출력 포맷 변경, 필드 추가/삭제 등)
- **Minor** (x.1.x): 기능 개선 (CoT 추가, Few-shot 예시 추가 등)
- **Patch** (x.x.1): 버그 수정 (오타, 제약 조건 조정 등)

### CHANGELOG.md 예시

```markdown
# Prompt Changelog

## [1.2.0] - 2025-11-23

### Added
- **CopywriterAgent**: Chain-of-Thought 프롬프트 추가 (5단계 프로세스)
- **ReviewerAgent**: Chain-of-Thought 프롬프트 추가 (5단계 검토)

### Changed
- **CopywriterAgent**: Headline 길이 제약 강화 (30자 → 20자)

### Fixed
- **OptimizerAgent**: SEO 최적화 지시사항 오타 수정

## [1.1.0] - 2025-11-16

### Added
- **CopywriterAgent**: product_detail 태스크 Few-shot 예시 2개 추가
- **DesignerAgent**: Canvas 통합 가이드라인 추가

### Changed
- **ReviewerAgent**: 검토 기준 5가지로 확대 (기존 3가지)

## [1.0.0] - 2025-11-10

### Added
- 초기 버전: CopywriterAgent, ReviewerAgent, OptimizerAgent, DesignerAgent
```

### Git Workflow

```bash
# 1. 새 프롬프트 버전 생성
cp prompts/copywriter/v1.1_product_detail.md prompts/copywriter/v1.2_product_detail.md

# 2. 프롬프트 수정
vim prompts/copywriter/v1.2_product_detail.md

# 3. Golden Set 테스트
python tests/golden_set_validator.py --agent copywriter

# 4. 통과 시 current 심볼릭 링크 업데이트
ln -sf v1.2_product_detail.md prompts/copywriter/current

# 5. CHANGELOG 업데이트
vim prompts/CHANGELOG.md

# 6. Git 커밋
git add prompts/
git commit -m "feat(prompts): CopywriterAgent v1.2 - Self-Consistency 추가"
git push
```

---

## 🎯 체크리스트

프롬프트 작성 시 다음 항목을 확인하세요:

- [ ] 명확한 역할 부여 (Role Prompting)
- [ ] 구체적 제약 조건 설정 (Constraint Setting)
- [ ] 중요 정보 시각적 강조 (Context Highlighting)
- [ ] 명확한 출력 형식 (JSON 스키마 + 예시)
- [ ] Chain-of-Thought 프로세스 (복잡한 작업 시)
- [ ] Few-shot Examples (2-5개)
- [ ] 금지 사항 명시 (예: 고정 예시 사용 금지)
- [ ] Golden Set 테스트 통과 (7.0 이상)
- [ ] 버전 관리 (CHANGELOG 업데이트)
- [ ] 회귀 테스트 통과 (기존 기능 정상 작동)

---

## 📚 참고 자료

1. **LLM Gateway 코드**: `app/services/llm/gateway.py`
2. **Agent 코드**: `app/services/agents/*.py`
3. **Golden Set**: `tests/golden_sets/copywriter_golden_set.json`
4. **Validator**: `tests/golden_set_validator.py`
5. **Context Engineering Plan**: `docs/CONTEXT_ENGINEERING_IMPROVEMENT_PLAN_2025-11-23.md`

---

**작성자**: B팀 (Backend)
**작성일**: 2025-11-23
**검토자**: A팀 (QA)
**다음 업데이트 예정일**: 2025-12-23

**Status**: 🟢 **ACTIVE**
